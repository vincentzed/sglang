import json
import glob

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

SERIES = [
    ("tp4", "Pure TP4", "#2a78d6"),
    ("dcp2_agrs", "DCP2 (ag_rs)", "#008300"),
    ("helix_a2a", "Helix: DCP2 a2a", "#e87ba4"),
    ("helix_a2a_qrep", "Helix: DCP2 a2a + replicate-q", "#eda100"),
]
NUM_GPUS = 4
INK, INK2 = "#1a1a19", "#5f5e58"

def load(name):
    pts = {}
    for line in open(f"/data/{name}.jsonl"):
        line = line.strip()
        if not line or '": ,' in line or ": }" in line.replace(", ", ","):
            continue
        try:
            d = json.loads(line)
        except json.JSONDecodeError:
            continue
        pts[(d["ctx"], d["cc"])] = d["median_itl_ms"]
    return pts

data = {name: load(name) for name, _, _ in SERIES}

fig, axes = plt.subplots(1, 2, figsize=(12.5, 5.2), dpi=170)
fig.patch.set_facecolor("white")

for ax, ctx, title in zip(axes, (32768, 131072), ("32K context", "128K context")):
    ax.set_facecolor("white")
    for name, label, color in SERIES:
        xs, ys, ccs = [], [], []
        for cc in (1, 4, 8, 16, 32):
            itl = data[name].get((ctx, cc))
            if itl is None:
                continue
            inter = 1000.0 / itl
            xs.append(inter)
            ys.append(cc * inter / NUM_GPUS)
            ccs.append(cc)
        ax.plot(xs, ys, "-o", color=color, linewidth=2, markersize=7,
                label=label, zorder=3)
        for x, y, cc in zip(xs, ys, ccs):
            ax.annotate(str(cc), (x, y), textcoords="offset points",
                        xytext=(6, 5), fontsize=8, color=INK2, zorder=4)
    ax.set_title(title + " window", fontsize=12, color=INK)
    ax.set_xlabel("per-user generation speed (tokens/sec for one user)", fontsize=10, color=INK)
    ax.grid(True, color="#ebebe6", linewidth=0.8, zorder=0)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color("#c3c2b7")
    ax.tick_params(colors=INK2, labelsize=9)

axes[0].set_ylabel("total generation speed per GPU (tokens/sec)", fontsize=10, color=INK)

# capacity-cliff annotation: tp4 @128k runs ≈17 effective concurrent beyond cc=16
itl = data["tp4"].get((131072, 32))
if itl:
    x, y = 1000.0 / itl, 32 * (1000.0 / itl) / NUM_GPUS
    axes[1].annotate(
        "TP4 runs out of KV memory at ~17 users in a 128K window —\nits 32-user point actually served ~17 with the rest waiting",
        (x, y), textcoords="offset points", xytext=(-8, 26), fontsize=8.5,
        color=INK, ha="right",
        arrowprops=dict(arrowstyle="-", color="#c3c2b7", lw=1),
    )

axes[0].legend(loc="upper right", fontsize=9, frameon=False, labelcolor=INK)
fig.suptitle(
    "GLM-5.2-NVFP4 on 4\u00d7B300: decode speed vs per-user speed as concurrent users increase",
    fontsize=13, color=INK, y=1.02,
)
fig.text(
    0.5, 0.955,
    "Each request: prompt fills the context window minus 1,024 tokens, then generates 1,024 tokens. "
    "The number beside each point is how many users are served at once.",
    fontsize=9.5, color=INK2, ha="center",
)
fig.tight_layout(rect=(0, 0, 1, 0.93))
fig.savefig("/data/pareto_glm52_dcp.png", bbox_inches="tight", facecolor="white")
print("saved")
